# Guia de Instalação e Uso - PDA Monitor

Este guia fornece instruções detalhadas para instalar e executar o aplicativo PDA Monitor em seu ambiente local.

## Requisitos do Sistema

- Python 3.8 ou superior
- Pip (gerenciador de pacotes Python)
- Navegador web moderno (Chrome, Firefox, Edge, etc.)

## Instalação

1. **Extraia o arquivo zip** em um diretório de sua preferência

2. **Crie um ambiente virtual Python** (recomendado):
   ```bash
   # No Windows
   python -m venv venv
   venv\Scripts\activate
   
   # No Linux/Mac
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Instale as dependências**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Inicialize o banco de dados** (na primeira execução):
   ```bash
   # No diretório raiz do projeto
   python -c "from src.main import app, db; app.app_context().push(); db.create_all()"
   ```

## Execução do Aplicativo

1. **Inicie o servidor Flask**:
   ```bash
   # No diretório raiz do projeto
   python -m src.main
   ```

2. **Acesse o aplicativo** em seu navegador:
   ```
   http://localhost:5000
   ```

## Uso do Aplicativo

### Upload de Planilhas

1. Acesse a aba "Upload" no menu superior
2. Prepare uma planilha Excel (.xlsx) ou CSV com as seguintes colunas:
   - `hubspot_id`: ID do cliente no HubSpot
   - `nome_empresa`: Nome da empresa
   - `saldo_atual`: Saldo atual de créditos
   - `data_validade`: Data de validade da licença (formato: DD/MM/AAAA)
3. Clique em "Escolher arquivo" e selecione sua planilha
4. Clique em "Enviar" para processar os dados

### Visualização do Dashboard

1. Acesse a aba "Dashboard" no menu superior
2. Visualize o resumo dos clientes classificados por cores:
   - 🔴 **Vermelho**: Consumo abaixo do ideal (<90%) - Subutilização
   - 🟡 **Amarelo**: Consumo próximo ao ideal (90-110%) - Adequado
   - 🟢 **Verde**: Consumo acima do ideal (>110%) - Risco de acabar antes da validade
3. Use a tabela detalhada para analisar cada cliente
   - Filtre clientes usando a caixa de busca
   - Ordene por qualquer coluna clicando no cabeçalho
   - Visualize o histórico de um cliente clicando no ícone de gráfico

### Arquivos de Exemplo

No diretório `sample_data` você encontrará dois arquivos de exemplo:

1. `dados_clientes_anterior.xlsx`: Dados do mês anterior (upload primeiro)
2. `dados_clientes_atual.xlsx`: Dados do mês atual (upload depois)

Para testar o aplicativo com dados reais, faça o upload desses arquivos na ordem indicada.

## Solução de Problemas

### Erro ao iniciar o servidor
- Verifique se todas as dependências foram instaladas corretamente
- Certifique-se de que a porta 5000 não está sendo usada por outro aplicativo

### Erro ao fazer upload de planilha
- Verifique se a planilha contém todas as colunas necessárias
- Certifique-se de que o formato da data está correto (DD/MM/AAAA)

### Dashboard não mostra dados
- Verifique se pelo menos uma planilha foi carregada com sucesso
- Para visualizar a classificação completa, é necessário ter pelo menos dois meses de dados

## Personalização

### Ajuste das Regras de Classificação

As regras de classificação estão definidas no arquivo `src/models/cliente.py`:

```python
def classificacao(self):
    """Classifica o cliente com base na taxa de consumo"""
    taxa = self.taxa_consumo()
    
    if taxa < 0.9:
        return "vermelho"  # Consumindo menos do que deveria
    elif taxa <= 1.1:
        return "amarelo"   # Consumindo próximo ao ideal
    else:
        return "verde"     # Consumindo mais do que deveria
```

Você pode ajustar os valores 0.9 e 1.1 para alterar as margens de classificação conforme necessário.

## Suporte

Se precisar de ajuda adicional ou tiver sugestões de melhorias, entre em contato.
