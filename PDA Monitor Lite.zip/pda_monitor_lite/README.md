# PDA Monitor - Aplicativo de Monitoramento de Créditos

O PDA Monitor é um aplicativo web para monitorar o consumo de créditos dos clientes na plataforma PDA, classificando-os visualmente com base na taxa de uso em relação à validade da licença.

## Funcionalidades Principais

- **Upload de Planilhas**: Sistema aceita arquivos Excel (.xlsx, .xls) ou CSV com dados dos clientes
- **Armazenamento de Histórico**: Mantém registro mensal dos saldos de cada cliente
- **Cálculos Automáticos**:
  - Consumo ideal mensal (saldo atual ÷ meses restantes até validade)
  - Consumo real (diferença entre saldos de meses consecutivos)
  - Taxa de consumo (consumo real ÷ consumo ideal)
- **Classificação Visual**:
  - 🔴 **Vermelho**: Consumo abaixo do ideal (<90%) - Subutilização
  - 🟡 **Amarelo**: Consumo próximo ao ideal (90-110%) - Adequado
  - 🟢 **Verde**: Consumo acima do ideal (>110%) - Risco de acabar antes da validade
- **Dashboard Interativo**:
  - Resumo geral com contagem por classificação
  - Tabela detalhada com filtros e ordenação
  - Visualização de histórico com gráficos

## Tecnologias Utilizadas

- **Backend**: Flask (Python) com SQLite para armazenamento
- **Frontend**: HTML, CSS, JavaScript com Vue.js
- **Processamento de Dados**: Pandas para manipulação de planilhas
- **Visualização**: Chart.js para gráficos

## Estrutura do Projeto

```
pda_monitor_app/
├── src/
│   ├── main.py                 # Ponto de entrada da aplicação Flask
│   ├── models/                 # Modelos de dados
│   │   ├── __init__.py         # Inicialização do banco de dados
│   │   ├── cliente.py          # Modelo Cliente
│   │   └── historico.py        # Modelo Histórico
│   ├── routes/                 # Rotas da API
│   │   ├── upload.py           # Rota para upload de planilhas
│   │   └── dashboard.py        # Rotas para dados do dashboard
│   ├── services/               # Serviços de negócio
│   │   └── processador.py      # Processamento de planilhas
│   ├── static/                 # Arquivos estáticos
│   │   ├── css/
│   │   │   └── styles.css      # Estilos da aplicação
│   │   └── js/
│   │       └── app.js          # Código JavaScript/Vue.js
│   └── templates/              # Templates HTML
│       └── index.html          # Página principal
├── uploads/                    # Diretório para arquivos enviados
├── sample_data/                # Dados de exemplo para testes
│   ├── dados_clientes_atual.xlsx
│   └── dados_clientes_anterior.xlsx
├── venv/                       # Ambiente virtual Python
└── requirements.txt            # Dependências Python
```

## Como Usar

1. **Preparação da Planilha**:
   - Crie uma planilha Excel ou CSV com as seguintes colunas:
     - `hubspot_id`: ID do cliente no HubSpot
     - `nome_empresa`: Nome da empresa
     - `saldo_atual`: Saldo atual de créditos
     - `data_validade`: Data de validade da licença (formato: DD/MM/AAAA)

2. **Upload de Dados**:
   - Acesse a aba "Upload" no aplicativo
   - Selecione o arquivo da planilha
   - Clique em "Enviar" para processar os dados

3. **Visualização do Dashboard**:
   - Acesse a aba "Dashboard" para ver o resumo e detalhes
   - Use os filtros e ordenação para analisar os dados
   - Clique no ícone de gráfico para ver o histórico de um cliente específico

## Regras de Classificação

- **Vermelho**: Cliente consumindo menos créditos do que deveria (subutilização)
  - Taxa de Consumo < 0.9 (menos de 90% do consumo ideal)
- **Amarelo**: Consumo próximo ao ideal
  - Taxa de Consumo entre 0.9 e 1.1 (±10% do consumo ideal)
- **Verde**: Cliente consumindo mais do que o ideal (risco de acabar antes da validade)
  - Taxa de Consumo > 1.1 (mais de 110% do consumo ideal)

## Instalação e Execução Local

1. Clone o repositório
2. Crie um ambiente virtual: `python -m venv venv`
3. Ative o ambiente virtual: `source venv/bin/activate` (Linux/Mac) ou `venv\Scripts\activate` (Windows)
4. Instale as dependências: `pip install -r requirements.txt`
5. Execute o aplicativo: `python -m src.main`
6. Acesse o aplicativo em `http://localhost:5000`

## Próximos Passos e Melhorias Futuras

- Exportação de relatórios em PDF
- Notificações automáticas para clientes com consumo inadequado
- Integração direta com a API do HubSpot
- Previsões de consumo baseadas em tendências históricas
