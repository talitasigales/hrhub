from flask import Blueprint, request, jsonify
import os
from werkzeug.utils import secure_filename
from src.services.processador import ProcessadorPlanilha

upload_bp = Blueprint('upload', __name__)

UPLOAD_FOLDER = '/home/ubuntu/pda_monitor_app/uploads'
ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv'}

# Criar pasta de uploads se não existir
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@upload_bp.route('/api/upload', methods=['POST'])
def upload_file():
    # Verificar se o arquivo está na requisição
    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum arquivo enviado'}), 400
    
    file = request.files['file']
    
    # Verificar se o nome do arquivo está vazio
    if file.filename == '':
        return jsonify({'error': 'Nome de arquivo vazio'}), 400
    
    # Verificar se o arquivo é de um tipo permitido
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        
        try:
            # Processar a planilha
            processador = ProcessadorPlanilha()
            resultados = processador.processar(filepath)
            
            return jsonify({
                'success': True,
                'message': 'Arquivo processado com sucesso',
                'resultados': resultados
            })
        except Exception as e:
            return jsonify({
                'error': f'Erro ao processar arquivo: {str(e)}'
            }), 500
    
    return jsonify({'error': 'Tipo de arquivo não permitido'}), 400
