from flask import Blueprint, jsonify
from src.models.cliente import Cliente
from src.models.historico import Historico
from sqlalchemy import func

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/api/dashboard/resumo', methods=['GET'])
def get_resumo():
    """Retorna um resumo da classificação dos clientes"""
    try:
        # Obter contagem de clientes por classificação
        clientes = Cliente.query.all()
        
        resumo = {
            'total': len(clientes),
            'vermelho': 0,
            'amarelo': 0,
            'verde': 0,
            'sem_dados': 0
        }
        
        for cliente in clientes:
            if len(cliente.historicos) < 2:
                resumo['sem_dados'] += 1
                continue
                
            classificacao = cliente.classificacao()
            if classificacao == 'vermelho':
                resumo['vermelho'] += 1
            elif classificacao == 'amarelo':
                resumo['amarelo'] += 1
            elif classificacao == 'verde':
                resumo['verde'] += 1
        
        return jsonify({
            'success': True,
            'data': resumo
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@dashboard_bp.route('/api/dashboard/detalhes', methods=['GET'])
def get_detalhes():
    """Retorna detalhes de todos os clientes para o dashboard"""
    try:
        clientes = Cliente.query.all()
        resultado = []
        
        for cliente in clientes:
            ultimo_historico = cliente.ultimo_historico()
            
            if not ultimo_historico:
                continue
                
            meses_restantes = cliente.meses_restantes()
            consumo_ideal = cliente.consumo_ideal_mensal()
            consumo_real = cliente.consumo_real_mensal()
            taxa = cliente.taxa_consumo()
            classificacao = cliente.classificacao()
            
            resultado.append({
                'id': cliente.id,
                'hubspot_id': cliente.hubspot_id,
                'nome_empresa': cliente.nome_empresa,
                'data_validade': cliente.data_validade.isoformat(),
                'saldo_atual': ultimo_historico.saldo,
                'meses_restantes': meses_restantes,
                'consumo_ideal': consumo_ideal,
                'consumo_real': consumo_real,
                'taxa_consumo': taxa,
                'classificacao': classificacao
            })
        
        return jsonify({
            'success': True,
            'data': resultado
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@dashboard_bp.route('/api/clientes/<int:cliente_id>/historico', methods=['GET'])
def get_historico_cliente(cliente_id):
    """Retorna o histórico de um cliente específico"""
    try:
        cliente = Cliente.query.get(cliente_id)
        
        if not cliente:
            return jsonify({
                'success': False,
                'error': 'Cliente não encontrado'
            }), 404
            
        historicos = sorted(cliente.historicos, key=lambda h: h.data_registro)
        resultado = []
        
        for historico in historicos:
            resultado.append({
                'data': historico.data_registro.isoformat(),
                'saldo': historico.saldo,
                'consumo_real': historico.consumo_real,
                'consumo_ideal': historico.consumo_ideal,
                'classificacao': historico.classificacao
            })
            
        return jsonify({
            'success': True,
            'data': resultado
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
