// Configuração da aplicação Vue
const app = Vue.createApp({
    data() {
        return {
            currentView: 'dashboard',
            apiBaseUrl: ''  // URL base da API (vazio para mesmo servidor)
        };
    },
    mounted() {
        // Verificar hash na URL para determinar a visualização inicial
        const hash = window.location.hash.substring(1);
        if (hash === 'upload') {
            this.currentView = 'upload';
        }
        
        // Configurar navegação por hash
        window.addEventListener('hashchange', () => {
            const hash = window.location.hash.substring(1);
            if (hash === 'dashboard' || hash === 'upload') {
                this.currentView = hash;
            }
        });
        
        // Remover o loading inicial
        document.getElementById('loading').style.display = 'none';
    },
    computed: {
        currentComponent() {
            return this.currentView + 'Component';
        }
    }
});

// Componente Dashboard
app.component('dashboardComponent', {
    template: '#dashboard-template',
    data() {
        return {
            resumo: {
                total: 0,
                vermelho: 0,
                amarelo: 0,
                verde: 0,
                sem_dados: 0
            },
            clientes: [],
            filtro: '',
            ordenacao: {
                campo: 'nome_empresa',
                direcao: 'asc'
            },
            clienteAtual: null,
            historico: [],
            historicoCarregando: false
        };
    },
    mounted() {
        this.carregarResumo();
        this.carregarDetalhes();
    },
    computed: {
        clientesFiltrados() {
            if (!this.filtro) {
                return this.ordenarClientes([...this.clientes]);
            }
            
            const filtroLower = this.filtro.toLowerCase();
            const filtrados = this.clientes.filter(cliente => 
                cliente.nome_empresa.toLowerCase().includes(filtroLower) ||
                cliente.hubspot_id.toLowerCase().includes(filtroLower)
            );
            
            return this.ordenarClientes(filtrados);
        }
    },
    methods: {
        async carregarResumo() {
            try {
                const response = await axios.get(`${this.$root.apiBaseUrl}/api/dashboard/resumo`);
                if (response.data.success) {
                    this.resumo = response.data.data;
                }
            } catch (error) {
                console.error('Erro ao carregar resumo:', error);
                alert('Erro ao carregar dados do resumo. Verifique o console para mais detalhes.');
            }
        },
        
        async carregarDetalhes() {
            try {
                const response = await axios.get(`${this.$root.apiBaseUrl}/api/dashboard/detalhes`);
                if (response.data.success) {
                    this.clientes = response.data.data;
                }
            } catch (error) {
                console.error('Erro ao carregar detalhes:', error);
                alert('Erro ao carregar dados detalhados. Verifique o console para mais detalhes.');
            }
        },
        
        async verHistorico(clienteId) {
            this.historicoCarregando = true;
            this.clienteAtual = this.clientes.find(c => c.id === clienteId);
            
            // Abrir modal
            const historicoModal = new bootstrap.Modal(document.getElementById('historicoModal'));
            historicoModal.show();
            
            try {
                const response = await axios.get(`${this.$root.apiBaseUrl}/api/clientes/${clienteId}/historico`);
                if (response.data.success) {
                    this.historico = response.data.data;
                    this.historicoCarregando = false;
                    
                    // Renderizar gráfico após um pequeno delay para garantir que o modal esteja visível
                    setTimeout(() => this.renderizarGrafico(), 300);
                }
            } catch (error) {
                console.error('Erro ao carregar histórico:', error);
                alert('Erro ao carregar histórico do cliente. Verifique o console para mais detalhes.');
                this.historicoCarregando = false;
            }
        },
        
        renderizarGrafico() {
            if (!this.historico || this.historico.length < 2) return;
            
            const ctx = document.getElementById('historicoGrafico');
            
            // Destruir gráfico anterior se existir
            if (window.historicoChart) {
                window.historicoChart.destroy();
            }
            
            // Preparar dados para o gráfico
            const labels = this.historico.map(h => this.formatarData(h.data));
            const dadosSaldo = this.historico.map(h => h.saldo);
            const dadosConsumoReal = this.historico.slice(1).map(h => h.consumo_real || 0);
            const dadosConsumoIdeal = this.historico.slice(1).map(h => h.consumo_ideal || 0);
            
            // Adicionar zero no início para alinhar com as datas
            dadosConsumoReal.unshift(0);
            dadosConsumoIdeal.unshift(0);
            
            window.historicoChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: 'Saldo',
                            data: dadosSaldo,
                            borderColor: 'rgba(54, 162, 235, 1)',
                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                            tension: 0.1,
                            yAxisID: 'y'
                        },
                        {
                            label: 'Consumo Real',
                            data: dadosConsumoReal,
                            borderColor: 'rgba(255, 99, 132, 1)',
                            backgroundColor: 'rgba(255, 99, 132, 0.2)',
                            tension: 0.1,
                            yAxisID: 'y1'
                        },
                        {
                            label: 'Consumo Ideal',
                            data: dadosConsumoIdeal,
                            borderColor: 'rgba(75, 192, 192, 1)',
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            tension: 0.1,
                            yAxisID: 'y1'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            title: {
                                display: true,
                                text: 'Saldo'
                            }
                        },
                        y1: {
                            type: 'linear',
                            display: true,
                            position: 'right',
                            title: {
                                display: true,
                                text: 'Consumo'
                            },
                            grid: {
                                drawOnChartArea: false
                            }
                        }
                    }
                }
            });
        },
        
        ordenarPor(campo) {
            if (this.ordenacao.campo === campo) {
                // Inverter direção se já estiver ordenando por este campo
                this.ordenacao.direcao = this.ordenacao.direcao === 'asc' ? 'desc' : 'asc';
            } else {
                // Novo campo, começar com ascendente
                this.ordenacao.campo = campo;
                this.ordenacao.direcao = 'asc';
            }
        },
        
        ordenarClientes(clientes) {
            const campo = this.ordenacao.campo;
            const fator = this.ordenacao.direcao === 'asc' ? 1 : -1;
            
            return clientes.sort((a, b) => {
                let valorA = a[campo];
                let valorB = b[campo];
                
                // Tratamento especial para datas
                if (campo === 'data_validade') {
                    valorA = new Date(valorA);
                    valorB = new Date(valorB);
                }
                
                if (valorA < valorB) return -1 * fator;
                if (valorA > valorB) return 1 * fator;
                return 0;
            });
        },
        
        iconeSorting(campo) {
            if (this.ordenacao.campo !== campo) {
                return 'bi-arrow-down-up';
            }
            
            return this.ordenacao.direcao === 'asc' ? 'bi-sort-down' : 'bi-sort-up';
        },
        
        corLinha(classificacao) {
            if (!classificacao) return '';
            return `tr-${classificacao}`;
        },
        
        corBadge(classificacao) {
            if (!classificacao) return 'bg-secondary';
            return `bg-${classificacao}`;
        },
        
        textoClassificacao(classificacao) {
            if (!classificacao) return 'Sem dados';
            
            const textos = {
                'vermelho': 'Subutilizado',
                'amarelo': 'Adequado',
                'verde': 'Superutilizado'
            };
            
            return textos[classificacao] || classificacao;
        },
        
        formatarNumero(valor) {
            if (valor === null || valor === undefined) return '-';
            return Number(valor).toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
        },
        
        formatarData(dataStr) {
            if (!dataStr) return '-';
            const data = new Date(dataStr);
            return data.toLocaleDateString('pt-BR');
        },
        
        formatarTaxa(taxa) {
            if (taxa === null || taxa === undefined) return '-';
            return (taxa * 100).toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + '%';
        }
    }
});

// Componente Upload
app.component('uploadComponent', {
    template: '#upload-template',
    data() {
        return {
            arquivo: null,
            enviando: false,
            resultado: null
        };
    },
    methods: {
        onFileChange(event) {
            const files = event.target.files;
            if (files.length > 0) {
                this.arquivo = files[0];
                this.resultado = null;
            }
        },
        
        async enviarArquivo() {
            if (!this.arquivo) {
                alert('Por favor, selecione um arquivo para enviar.');
                return;
            }
            
            this.enviando = true;
            this.resultado = null;
            
            const formData = new FormData();
            formData.append('file', this.arquivo);
            
            try {
                const response = await axios.post(`${this.$root.apiBaseUrl}/api/upload`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
                
                this.resultado = response.data;
            } catch (error) {
                console.error('Erro ao enviar arquivo:', error);
                
                this.resultado = {
                    success: false,
                    error: error.response?.data?.error || 'Erro ao processar o arquivo. Verifique o console para mais detalhes.'
                };
            } finally {
                this.enviando = false;
            }
        },
        
        irParaDashboard() {
            window.location.hash = 'dashboard';
        }
    }
});

// Montar a aplicação
app.mount('#app');
