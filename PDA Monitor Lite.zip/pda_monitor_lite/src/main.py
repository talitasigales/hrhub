import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, render_template, send_from_directory
from flask_cors import CORS
import os

# Inicializar o aplicativo Flask
app = Flask(__name__)
CORS(app)

# Configurar o banco de dados SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pda_monitor.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Importar e inicializar o banco de dados
from src.models import db
db.init_app(app)

# Importar modelos após a inicialização do db
from src.models.cliente import Cliente
from src.models.historico import Historico

# Importar e registrar blueprints
from src.routes.upload import upload_bp
from src.routes.dashboard import dashboard_bp

app.register_blueprint(upload_bp)
app.register_blueprint(dashboard_bp)

# Criar pasta de uploads se não existir
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Rota para a página inicial
@app.route('/')
def index():
    return render_template('index.html')

# Rota para servir arquivos estáticos
@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

# Criar tabelas do banco de dados
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
