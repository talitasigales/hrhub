from src.models import db
from datetime import datetime

class Historico(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cliente_id = db.Column(db.Integer, db.ForeignKey('cliente.id'), nullable=False)
    data_registro = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    saldo = db.Column(db.Float, nullable=False)
    consumo_real = db.Column(db.Float, nullable=True)
    consumo_ideal = db.Column(db.Float, nullable=True)
    classificacao = db.Column(db.String(10), nullable=True)
    
    def __repr__(self):
        return f'<Historico {self.data_registro} - {self.saldo}>'
    
    def atualizar_metricas(self, cliente):
        """Atualiza as métricas calculadas com base no cliente"""
        self.consumo_ideal = cliente.consumo_ideal_mensal()
        self.consumo_real = cliente.consumo_real_mensal()
        self.classificacao = cliente.classificacao()
