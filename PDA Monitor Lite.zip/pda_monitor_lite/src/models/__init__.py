from flask_sqlalchemy import SQLAlchemy

# Inicializar o objeto db que será importado pelos modelos
db = SQLAlchemy()
