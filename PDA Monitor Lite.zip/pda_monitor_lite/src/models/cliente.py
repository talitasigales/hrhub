from src.models import db
from datetime import datetime, date
from dateutil.relativedelta import relativedelta

class Cliente(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    hubspot_id = db.Column(db.String(50), unique=True, nullable=False)
    nome_empresa = db.Column(db.String(100), nullable=False)
    data_validade = db.Column(db.Date, nullable=False)
    historicos = db.relationship('Historico', backref='cliente', lazy=True, cascade="all, delete-orphan")
    
    def __repr__(self):
        return f'<Cliente {self.nome_empresa}>'
    
    def meses_restantes(self):
        """Calcula quantos meses restam até a validade da licença"""
        hoje = date.today()
        if hoje > self.data_validade:
            return 0
        
        delta = relativedelta(self.data_validade, hoje)
        return delta.years * 12 + delta.months + (1 if delta.days > 0 else 0)
    
    def ultimo_historico(self):
        """Retorna o registro de histórico mais recente"""
        if not self.historicos:
            return None
        return sorted(self.historicos, key=lambda h: h.data_registro, reverse=True)[0]
    
    def penultimo_historico(self):
        """Retorna o penúltimo registro de histórico"""
        if len(self.historicos) < 2:
            return None
        return sorted(self.historicos, key=lambda h: h.data_registro, reverse=True)[1]
    
    def consumo_ideal_mensal(self):
        """Calcula o consumo ideal mensal baseado no saldo atual e meses restantes"""
        ultimo = self.ultimo_historico()
        if not ultimo or self.meses_restantes() == 0:
            return 0
        
        return ultimo.saldo / self.meses_restantes()
    
    def consumo_real_mensal(self):
        """Calcula o consumo real do último mês"""
        ultimo = self.ultimo_historico()
        penultimo = self.penultimo_historico()
        
        if not ultimo or not penultimo:
            return 0
        
        return max(0, penultimo.saldo - ultimo.saldo)
    
    def taxa_consumo(self):
        """Calcula a taxa de consumo (real/ideal)"""
        ideal = self.consumo_ideal_mensal()
        real = self.consumo_real_mensal()
        
        if ideal == 0:
            return 0
        
        return real / ideal
    
    def classificacao(self):
        """Classifica o cliente com base na taxa de consumo"""
        taxa = self.taxa_consumo()
        
        if taxa < 0.9:
            return "vermelho"  # Consumindo menos do que deveria
        elif taxa <= 1.1:
            return "amarelo"   # Consumindo próximo ao ideal
        else:
            return "verde"     # Consumindo mais do que deveria
