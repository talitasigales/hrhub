from src.models import db
import pandas as pd
from datetime import datetime
import os
from src.models.cliente import Cliente
from src.models.historico import Historico

class ProcessadorPlanilha:
    """Classe responsável por processar planilhas de dados de clientes"""
    
    def __init__(self):
        self.formatos_suportados = ['.xlsx', '.xls', '.csv']
    
    def validar_arquivo(self, arquivo):
        """Valida se o arquivo está em um formato suportado"""
        _, extensao = os.path.splitext(arquivo)
        return extensao.lower() in self.formatos_suportados
    
    def ler_planilha(self, caminho_arquivo):
        """Lê a planilha e retorna um DataFrame"""
        _, extensao = os.path.splitext(caminho_arquivo)
        
        if extensao.lower() in ['.xlsx', '.xls']:
            return pd.read_excel(caminho_arquivo)
        elif extensao.lower() == '.csv':
            return pd.read_csv(caminho_arquivo)
        else:
            raise ValueError(f"Formato de arquivo não suportado: {extensao}")
    
    def validar_colunas(self, df):
        """Valida se o DataFrame contém as colunas necessárias"""
        colunas_necessarias = ['hubspot_id', 'nome_empresa', 'saldo_atual', 'data_validade']
        colunas_faltantes = [col for col in colunas_necessarias if col not in df.columns]
        
        if colunas_faltantes:
            raise ValueError(f"Colunas faltantes na planilha: {', '.join(colunas_faltantes)}")
        
        return True
    
    def processar(self, caminho_arquivo):
        """Processa a planilha e atualiza o banco de dados"""
        if not self.validar_arquivo(caminho_arquivo):
            raise ValueError("Formato de arquivo não suportado")
        
        df = self.ler_planilha(caminho_arquivo)
        self.validar_colunas(df)
        
        # Converter data_validade para formato de data
        df['data_validade'] = pd.to_datetime(df['data_validade']).dt.date
        
        # Data de registro atual
        data_registro = datetime.utcnow().date()
        
        # Processar cada linha da planilha
        resultados = {
            'novos': 0,
            'atualizados': 0,
            'erros': 0
        }
        
        for _, row in df.iterrows():
            try:
                # Verificar se o cliente já existe
                cliente = Cliente.query.filter_by(hubspot_id=row['hubspot_id']).first()
                
                if not cliente:
                    # Criar novo cliente
                    cliente = Cliente(
                        hubspot_id=row['hubspot_id'],
                        nome_empresa=row['nome_empresa'],
                        data_validade=row['data_validade']
                    )
                    db.session.add(cliente)
                    db.session.flush()  # Para obter o ID do cliente
                    resultados['novos'] += 1
                else:
                    # Atualizar cliente existente
                    cliente.nome_empresa = row['nome_empresa']
                    cliente.data_validade = row['data_validade']
                    resultados['atualizados'] += 1
                
                # Criar novo registro de histórico
                historico = Historico(
                    cliente_id=cliente.id,
                    data_registro=data_registro,
                    saldo=float(row['saldo_atual'])
                )
                db.session.add(historico)
                
                # Commit para garantir que o histórico seja salvo
                db.session.commit()
                
                # Atualizar métricas do histórico
                if len(cliente.historicos) >= 2:
                    historico.atualizar_metricas(cliente)
                    db.session.commit()
                
            except Exception as e:
                db.session.rollback()
                resultados['erros'] += 1
                print(f"Erro ao processar linha {_}: {str(e)}")
        
        return resultados
